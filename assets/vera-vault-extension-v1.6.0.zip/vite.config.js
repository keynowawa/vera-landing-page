import { defineConfig } from "vite";
import wasm from "vite-plugin-wasm";
import topLevelAwait from "vite-plugin-top-level-await";

export default defineConfig({
  plugins: [wasm(), topLevelAwait()],
  build: {
    outDir: "dist",
    emptyOutDir: true,

    rollupOptions: {
      input: {
        background: "src/background.js",
      },
      output: {
        // Use ES module format — Chrome MV3 service workers support type: "module"
        format: "es",
        entryFileNames: "[name].js",
        // Put WASM files alongside the JS
        assetFileNames: "[name].[ext]",
      },
    },

    // Target modern Chrome
    target: "chrome109",

    // Don't minify for easier debugging
    minify: false,
  },

  resolve: {
    // Route to the browser/WASM build of bbs-signatures
    conditions: ["browser", "import", "module", "default"],
    alias: {
      buffer: "buffer/",
    },
  },

  define: {
    global: "globalThis",
  },
});
