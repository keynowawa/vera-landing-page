// ═══════════════════════════════════════════════════════════════
// VERA Vault — Popup Controller
// View routing, chrome.storage integration, credential rendering
// ═══════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  const I = window.VERA_ICONS;
  const icon = window.veraIcon;

  // ─── Inject Icons ───────────────────────────────────────────
  function injectIcons() {
    // Header
    document.getElementById('headerIcon').innerHTML = icon('shieldCheck');

    // Navigation
    document.getElementById('navDashIcon').innerHTML = icon('layoutDashboard');
    document.getElementById('navCredIcon').innerHTML = icon('vault');
    document.getElementById('navHistIcon').innerHTML = icon('clock');
    document.getElementById('navSettIcon').innerHTML = icon('settings');
    document.getElementById('navAboutIcon').innerHTML = icon('info');

    // Dashboard stats
    document.getElementById('statVerifiedIcon').innerHTML = icon('checkCircle');
    document.getElementById('statPrivacyIcon').innerHTML = icon('eyeOff');

    // Explainer
    document.getElementById('explainerInfoIcon').innerHTML = icon('info');
    document.getElementById('explainerChevron').innerHTML = icon('chevronRight');
    document.getElementById('exp-store-icon').innerHTML = icon('store');
    document.getElementById('exp-shield-icon').innerHTML = icon('shield');
    document.getElementById('exp-check-icon').innerHTML = icon('checkCircle');

    // Settings
    document.getElementById('settingMoonIcon').innerHTML = icon('moon');
    document.getElementById('settingTrashIcon').innerHTML = icon('trash2');
    document.getElementById('settingResetIcon').innerHTML = icon('rotateCcw');
    document.getElementById('settingTagIcon').innerHTML = icon('tag');

    // About
    document.getElementById('aboutLogo').innerHTML = icon('shieldCheck', 48);

    // Detail back button
    document.getElementById('detailBack').innerHTML = icon('chevronLeft');

    // Onboarding icons
    document.getElementById('onb-icon-0').innerHTML = icon('shield', 36);
    document.getElementById('onb-icon-1').innerHTML = icon('fingerprint', 36);
    document.getElementById('onb-icon-2').innerHTML = icon('eyeOff', 36);
    document.getElementById('onboardingBtnIcon').innerHTML = icon('arrowRight');
  }

  // ─── View Router ────────────────────────────────────────────
  const views = ['dashboard', 'credentials', 'history', 'settings', 'about'];
  let currentView = 'dashboard';

  function showView(viewName) {
    views.forEach(v => {
      const viewEl = document.getElementById(`view-${v}`);
      const navEl = document.getElementById(`nav-${v}`);
      if (viewEl) viewEl.classList.toggle('active', v === viewName);
      if (navEl) navEl.classList.toggle('active', v === viewName);
    });
    currentView = viewName;

    // Refresh view data
    if (viewName === 'dashboard') renderDashboard();
    if (viewName === 'credentials') renderCredentials();
    if (viewName === 'history') renderHistory();
  }

  // Nav click handlers
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const view = btn.getAttribute('data-view');
      if (view) showView(view);
    });
  });

  // ─── Chrome Storage Helpers ─────────────────────────────────
  async function getCredentials() {
    return new Promise(resolve => {
      chrome.storage.local.get(['credentials'], result => {
        resolve(result.credentials || []);
      });
    });
  }

  async function getHistory() {
    return new Promise(resolve => {
      chrome.storage.local.get(['verificationHistory'], result => {
        resolve(result.verificationHistory || []);
      });
    });
  }

  async function clearCredentials() {
    return new Promise(resolve => {
      chrome.storage.local.set({ credentials: [] }, () => {
        chrome.action.setBadgeText({ text: '' });
        resolve();
      });
    });
  }

  async function resetVault() {
    return new Promise(resolve => {
      chrome.storage.local.clear(() => {
        chrome.action.setBadgeText({ text: '' });
        resolve();
      });
    });
  }

  // ─── Time Formatting ───────────────────────────────────────
  function timeAgo(dateStr) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  }

  // ─── Dashboard ──────────────────────────────────────────────
  async function renderDashboard() {
    const credentials = await getCredentials();
    const history = await getHistory();

    // Update counts
    document.getElementById('credCount').textContent = credentials.length;
    const verified = history.filter(h => h.verified).length;
    document.getElementById('verifiedCount').textContent = verified;

    // Recent activity
    const activityEl = document.getElementById('recentActivity');
    if (credentials.length === 0) {
      activityEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">${icon('vault', 40)}</div>
          <div class="empty-title">No activity yet</div>
          <div class="empty-desc">Visit a VERA-enabled store to receive your first credential.</div>
        </div>`;
      return;
    }

    // Show last 3 credentials as activity items
    const recent = [...credentials].reverse().slice(0, 3);
    activityEl.innerHTML = recent.map(cred => {
      const subject = cred.credential?.credentialSubject || {};
      return `
        <div class="activity-item">
          <div class="activity-icon">${icon('shieldCheck')}</div>
          <div class="activity-text">
            <div class="activity-title">Credential from ${subject.storeID || 'Unknown'}</div>
            <div class="activity-time">${timeAgo(cred.storedAt)}</div>
          </div>
        </div>`;
    }).join('');
  }

  // ─── Credentials ────────────────────────────────────────────
  async function renderCredentials() {
    const credentials = await getCredentials();
    const listEl = document.getElementById('credentialsList');

    if (credentials.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">${icon('vault', 40)}</div>
          <div class="empty-title">No credentials</div>
          <div class="empty-desc">Purchase a product on a VERA-enabled store to receive a verifiable credential.</div>
        </div>`;
      return;
    }

    listEl.innerHTML = [...credentials].reverse().map((cred, idx) => {
      const subject = cred.credential?.credentialSubject || {};
      const realIdx = credentials.length - 1 - idx;
      return `
        <div class="credential-card" data-index="${realIdx}">
          <div class="cred-row">
            ${icon('store')}
            <span class="cred-label">Store</span>
            <span class="cred-value">${subject.storeID || 'N/A'}</span>
          </div>
          <div class="cred-row">
            ${icon('package')}
            <span class="cred-label">Product</span>
            <span class="cred-value">${subject.itemSKU || 'N/A'}</span>
          </div>
          <div class="cred-row">
            ${icon('calendar')}
            <span class="cred-label">Date</span>
            <span class="cred-value">${timeAgo(cred.storedAt)}</span>
          </div>
          <div class="cred-footer">
            <span class="cred-badge secured">${icon('shieldCheck')} Secured</span>
            <span class="cred-arrow">${icon('chevronRight')}</span>
          </div>
        </div>`;
    }).join('');

    // Add click handlers
    listEl.querySelectorAll('.credential-card').forEach(card => {
      card.addEventListener('click', () => {
        const idx = parseInt(card.getAttribute('data-index'));
        openCredentialDetail(credentials[idx], idx);
      });
    });
  }

  // ─── Credential Detail ──────────────────────────────────────
  function openCredentialDetail(cred, index) {
    const detailView = document.getElementById('detailView');
    const detailBody = document.getElementById('detailBody');
    const subject = cred.credential?.credentialSubject || {};

    detailBody.innerHTML = `
      <div class="detail-section">
        <div class="detail-section-title">${icon('eye')} Revealed to Merchants</div>
        <div class="detail-field">
          <span class="detail-field-label">Store ID</span>
          <span class="detail-field-value revealed">${subject.storeID || 'N/A'}</span>
        </div>
        <div class="detail-field">
          <span class="detail-field-label">Item SKU</span>
          <span class="detail-field-value revealed">${subject.itemSKU || 'N/A'}</span>
        </div>
      </div>
      <div class="detail-section">
        <div class="detail-section-title">${icon('eyeOff')} Protected by Zero-Knowledge Proof</div>
        <div class="detail-field">
          <span class="detail-field-label">Invoice ID</span>
          <span class="detail-field-value hidden">${'\u2022'.repeat(12)}</span>
        </div>
        <div class="detail-field">
          <span class="detail-field-label">Purchase Date</span>
          <span class="detail-field-value hidden">${'\u2022'.repeat(12)}</span>
        </div>
      </div>
      <div class="detail-section">
        <div class="detail-section-title">${icon('info')} Metadata</div>
        <div class="detail-field">
          <span class="detail-field-label">Received</span>
          <span class="detail-field-value">${new Date(cred.storedAt).toLocaleString()}</span>
        </div>
        <div class="detail-field">
          <span class="detail-field-label">Issuer</span>
          <span class="detail-field-value" style="font-size:11px">${cred.credential?.issuer || 'Unknown'}</span>
        </div>
        <div class="detail-field">
          <span class="detail-field-label">Type</span>
          <span class="detail-field-value">BBS+ Signature</span>
        </div>
      </div>
      <button class="detail-delete" id="deleteCredBtn">
        ${icon('trash2')} Delete Credential
      </button>`;

    detailView.classList.add('active');

    // Delete handler
    document.getElementById('deleteCredBtn').addEventListener('click', () => {
      showConfirm(
        'Delete Credential',
        'This credential will be permanently removed from your vault. This action cannot be undone.',
        'Delete',
        async () => {
          const creds = await getCredentials();
          creds.splice(index, 1);
          await new Promise(resolve => {
            chrome.storage.local.set({ credentials: creds }, resolve);
          });
          if (creds.length > 0) {
            chrome.action.setBadgeText({ text: String(creds.length) });
          } else {
            chrome.action.setBadgeText({ text: '' });
          }
          detailView.classList.remove('active');
          showToast('Credential deleted', 'success');
          renderCredentials();
          renderDashboard();
        }
      );
    });
  }

  // Detail back button
  document.getElementById('detailBack').addEventListener('click', () => {
    document.getElementById('detailView').classList.remove('active');
  });

  // ─── History ────────────────────────────────────────────────
  async function renderHistory() {
    const history = await getHistory();
    const listEl = document.getElementById('historyList');

    if (history.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">${icon('clock', 40)}</div>
          <div class="empty-title">No verifications yet</div>
          <div class="empty-desc">Your verification history will appear here after you submit a verified review.</div>
        </div>`;
      return;
    }

    listEl.innerHTML = [...history].reverse().map(h => {
      const isVerified = h.verified;
      return `
        <div class="history-item">
          <div class="history-icon ${isVerified ? 'verified' : 'failed'}">
            ${isVerified ? icon('checkCircle') : icon('xCircle')}
          </div>
          <div class="history-info">
            <div class="history-title">${h.storeID || 'Unknown Store'} — ${h.itemSKU || 'Unknown'}</div>
            <div class="history-meta">${timeAgo(h.timestamp)}</div>
          </div>
          <span class="history-badge ${isVerified ? 'verified' : 'failed'}">
            ${isVerified ? 'Verified' : 'Failed'}
          </span>
        </div>`;
    }).join('');
  }

  // ─── Toast Notifications ────────────────────────────────────
  function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const iconMap = {
      success: icon('checkCircle'),
      error: icon('xCircle'),
      warning: icon('alertTriangle'),
      info: icon('info'),
    };

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${iconMap[type] || iconMap.info}</span>
      <span class="toast-text">${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('dismissing');
      setTimeout(() => toast.remove(), 200);
    }, 3000);
  }

  // ─── Confirm Dialog ─────────────────────────────────────────
  let confirmCallback = null;

  function showConfirm(title, message, actionText, callback) {
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    document.getElementById('confirmAction').textContent = actionText;
    confirmCallback = callback;
    document.getElementById('confirmOverlay').classList.add('active');
  }

  document.getElementById('confirmCancel').addEventListener('click', () => {
    document.getElementById('confirmOverlay').classList.remove('active');
    confirmCallback = null;
  });

  document.getElementById('confirmAction').addEventListener('click', async () => {
    document.getElementById('confirmOverlay').classList.remove('active');
    if (confirmCallback) {
      await confirmCallback();
      confirmCallback = null;
    }
  });

  // ─── Settings Handlers ──────────────────────────────────────
  document.getElementById('clearCredsBtn').addEventListener('click', () => {
    showConfirm(
      'Clear Credentials',
      'All stored credentials will be permanently deleted. You will need to make new purchases to receive new credentials.',
      'Clear All',
      async () => {
        await clearCredentials();
        showToast('All credentials cleared', 'success');
        renderDashboard();
        renderCredentials();
      }
    );
  });

  document.getElementById('resetVaultBtn').addEventListener('click', () => {
    showConfirm(
      'Reset Vault',
      'This will clear all data including credentials, verification history, and preferences. The onboarding screen will appear again on next open.',
      'Reset Everything',
      async () => {
        await resetVault();
        showToast('Vault has been reset', 'success');
        renderDashboard();
        renderCredentials();
        renderHistory();
      }
    );
  });

  // Explainer toggle
  document.getElementById('explainerToggle').addEventListener('click', () => {
    const body = document.getElementById('explainerBody');
    const chevron = document.getElementById('explainerChevron');
    body.classList.toggle('open');
    chevron.style.transform = body.classList.contains('open') ? 'rotate(90deg)' : '';
  });

  // ─── Onboarding ─────────────────────────────────────────────
  let onboardingSlide = 0;

  async function checkOnboarding() {
    return new Promise(resolve => {
      chrome.storage.local.get(['onboardingComplete'], result => {
        if (!result.onboardingComplete) {
          document.getElementById('onboarding').classList.add('active');
        }
        resolve();
      });
    });
  }

  document.getElementById('onboardingBtn').addEventListener('click', () => {
    onboardingSlide++;
    if (onboardingSlide >= 3) {
      // Complete onboarding
      chrome.storage.local.set({ onboardingComplete: true });
      document.getElementById('onboarding').classList.remove('active');
      showToast('Welcome to VERA Vault', 'success');
      return;
    }

    // Update slide
    document.querySelectorAll('.onboarding-slide').forEach(s => s.classList.remove('active'));
    document.querySelector(`[data-slide="${onboardingSlide}"]`).classList.add('active');

    // Update dots
    document.querySelectorAll('.onboarding-dot').forEach(d => d.classList.remove('active'));
    document.querySelector(`[data-dot="${onboardingSlide}"]`).classList.add('active');

    // Update button text on last slide
    if (onboardingSlide === 2) {
      document.getElementById('onboardingBtnText').textContent = 'Get Started';
    }
  });

  // ─── Listen for Storage Changes (live updates) ──────────────
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.credentials) {
        const newCreds = changes.credentials.newValue || [];
        const oldCreds = changes.credentials.oldValue || [];
        if (newCreds.length > oldCreds.length) {
          showToast('Credential securely stored', 'success');
        }
        if (currentView === 'dashboard') renderDashboard();
        if (currentView === 'credentials') renderCredentials();
      }
      if (changes.verificationHistory) {
        const newHist = changes.verificationHistory.newValue || [];
        const oldHist = changes.verificationHistory.oldValue || [];
        if (newHist.length > oldHist.length) {
          const latest = newHist[newHist.length - 1];
          if (latest.verified) {
            showToast('Purchase verified successfully', 'success');
          } else {
            showToast('Verification failed', 'error');
          }
        }
        if (currentView === 'dashboard') renderDashboard();
        if (currentView === 'history') renderHistory();
      }
    }
  });

  // ─── Initialize ─────────────────────────────────────────────
  injectIcons();
  checkOnboarding();
  renderDashboard();
});
